#Academic_Certificate_Authentication

Aim of this project is to design and develop an anti-fraud identity intelligence blockchain solution for
educational certificates.This allows an independent verifier to check the authenticity of such certificates by retreiving the hash value from the Bitcoin blockchain and comparing it to the local receipt.

#workflow:

There are 3 nodes in system :
1. University
2. Student
3. Employ

1. University send details using its wallet address.
2. Smart contract owner Add college after verifiction.
3. University will create certificate.
4. System send Digital copy,which  will store in IPFS.
5. IPFS will return unique hash to the system.
6. System will sent certificate details and hash value to blockchain.
7. Transaction id will send to student.
8. Student  will share transaction id with employ.
9. Employ will verify transaction id with system.

#Deploy:
creating this javascript,solidity,web3 used.

- Start http-server and run main.html file.
- create node on metamask using key from ganache.
- Run organz.sol and emp.sol program run with metamask and ganache on remix ide.
- setup connection of .sol with .html file then run organz.html and emp.html on browser.
- Deploy it.

#Essential Softwares:

-ganache software
-Metamask
-remix ide
-web3 connection with npm and nodejs 
-ipfs




